//Este componente deberia recibir por props y mostrar en pantalla la informacion
//que envia el usuario

function Card() {
  return (
    <div>
      <h2>Esto es un componente</h2>
    </div>
  );
}

export default Card;
