function App() {
  //Aqui deberias agregar los estados y los handlers para los inputs

  return (
    <div className="App">
      <h1>Elige un color</h1>
      <form>{/* aqui deberias escribir tu codigo */}</form>
    </div>
  );
}

export default App;
