## Para correr el proyecto

`npm install`

`npm run dev`
